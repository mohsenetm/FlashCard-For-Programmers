require('./bootstrap');
window.Vue=require('vue');
window.hljs=require('highlight.js');
window.onload = function () {
    let app = new Vue({
        el: '#app',
    });
};

