<div class="row">
    <div class="col-4"><a class="btn btn-light" href="{{route('decks.index')}}">مشاهده دسته ها</a></div>
    <div class="col-4"><a class="btn btn-light" href="{{route('decks.create')}}">افزودن دسته ها</a></div>
    <div class="col-4"><a class="btn btn-light" href="{{route('flash.read.all')}}">مطالعه فلش کارت ها</a></div>
</div>
